import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
import statsmodels.api as sm
import matplotlib.pyplot as plt
import seaborn as sns
df = pd.read_csv('salary_dataset.csv')
df['education_level'] = df['education_level'].fillna(df['education_level'].mode()[0])
df['years_experience'] = df['years_experience'].fillna(df['years_experience'].median())
df['performance_score'] = df['performance_score'].fillna(df['performance_score'].median())
df['education_level_encoded'] = df['education_level'].map({'HighSchool':0, "Associate's":1, 'Bachelors':2, 'Masters':3, 'PhD':4})
df['remote_worker_encoded'] = df['remote_worker'].map({'No':0, 'Yes':1})
df = pd.get_dummies(df, columns=['gender', 'industry', 'city', 'job_title'], drop_first=True, dtype=int)
df.drop(columns=['education_level', 'remote_worker'], inplace=True)
df['salary_bins'] = pd.qcut(df['salary'], q=5, labels=False)
X = df.drop(columns=['salary', 'salary_bins'])
y = df['salary']
x_train, x_test, y_train, y_test = train_test_split(X, y,stratify=df['salary_bins'], test_size=0.2, random_state=42)
model = LinearRegression()
model.fit(x_train, y_train)
X_train_const = sm.add_constant(x_train)
X_test_const = sm.add_constant(x_test)

model = sm.OLS(y_train, X_train_const).fit()
summary_df = pd.DataFrame({
    'coef': model.params,
    'std_err': model.bse,
    'p_value': model.pvalues,
    'ci_lower': model.conf_int()[0],
    'ci_upper': model.conf_int()[1]
})
top_5_influential = summary_df.drop('const').reindex(summary_df.drop('const')['coef'].abs().sort_values(ascending=False).index).head(5)
y_pred = model.predict(X_test_const)
rmse = np.sqrt(np.mean((y_test - y_pred) ** 2))
mae=np.mean(np.abs(y_test - y_pred))
r2=model.rsquared
print("Top 5 Influential Features on Salary:")
print(top_5_influential)

residuals_train = model.resid
fitted_train = model.fittedvalues

# Plot 1: Residuals vs Fitted (Linearity & Homoscedasticity)
plt.figure(figsize=(14, 6))

plt.subplot(1, 2, 1)
sns.scatterplot(x=fitted_train, y=residuals_train, alpha=0.3)
plt.axhline(0, color='red', linestyle='--')
plt.xlabel('Fitted Values')
plt.ylabel('Residuals')
plt.title('Residuals vs Fitted Values')

# Plot 2: Actual vs Predicted (Linearity check)
plt.subplot(1, 2, 2)
sns.scatterplot(x=y_train, y=fitted_train, alpha=0.3)
plt.plot([y_train.min(), y_train.max()], [y_train.min(), y_train.max()], 'r--')
plt.xlabel('Actual Values')
plt.ylabel('Predicted Values')
plt.title('Actual vs Predicted Values')

plt.tight_layout()
plt.show()

