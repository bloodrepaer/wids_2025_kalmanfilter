import torch
import torch.nn as nn
import torch.optim as optim

# 1. Model Definition
class DigitClassifier(nn.Module):
    def __init__(self):
        super().__init__()
        self.layer1 = nn.Linear(784, 256)
        self.relu = nn.ReLU()
        self.layer2 = nn.Linear(256, 128)
        self.layer3 = nn.Linear(128, 10)

    def forward(self, x):
        x = x.view(-1, 784) 
        x = self.relu(self.layer1(x))
        x = self.relu(self.layer2(x))
        x = self.layer3(x)
        return x

# 2. Setup
model = DigitClassifier()
loss_function = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters())

# Mock Data (10 batches of 64 images)
fake_loader = []
for i in range(10):
    inputs = torch.randn(64, 784)
    labels = torch.randint(0, 10, (64,))
    fake_loader.append((inputs, labels))
# 3. Training Loop
for epoch in range(5):
    for batch_inputs, batch_labels in fake_loader:
        
        # Forward pass
        predictions = model(batch_inputs)
        loss = loss_function(predictions, batch_labels)
        
        # Backward pass
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        
    print(f"Epoch {epoch+1} Loss: {loss.item():.4f}")

print("Done!")