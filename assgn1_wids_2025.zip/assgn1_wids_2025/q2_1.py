"the code is generated and i will explain the insights"
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
df = pd.read_csv('salary_dataset.csv')
print(df.describe())
# Set up the figure for histograms
fig, axes = plt.subplots(2, 2, figsize=(14, 10))
fig.suptitle('Histograms of Numerical Variables', fontsize=16)

sns.histplot(data=df, x='salary', kde=True, ax=axes[0, 0], color='skyblue')
axes[0, 0].set_title('Distribution of Salary')

# Histogram for Age
sns.histplot(data=df, x='age', kde=True, ax=axes[0, 1], color='lightgreen')
axes[0, 1].set_title('Distribution of Age')

# Histogram for Years of Experience
sns.histplot(data=df, x='years_experience', kde=True, ax=axes[1, 0], color='salmon')
axes[1, 0].set_title('Distribution of Years of Experience')

# Histogram for Performance Score
sns.histplot(data=df, x='performance_score', kde=True, ax=axes[1, 1], color='orange')
axes[1, 1].set_title('Distribution of Performance Score')

plt.tight_layout(rect=[0, 0.03, 1, 0.95])
plt.savefig('histograms.png')
plt.close()
"The average salary is approximately $106k, with a median of $103k, indicating a relatively symmetric distribution, though the maximum value of $497k suggests some high-earning outliers."
"the average work ex is 16 years which indicates that most employees have significant experience in their fields."
# Correlation Heatmap
plt.figure(figsize=(10, 8))
numeric_df = df[['age', 'years_experience', 'performance_score', 'previous_companies', 'salary']]
correlation_matrix = numeric_df.corr()
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt=".2f", linewidths=0.5)
plt.title('Correlation Heatmap of Numerical Features')
plt.savefig('correlation_heatmap.png')
plt.close()
fig, axes = plt.subplots(3, 1, figsize=(12, 18))
"years of experience and age are the 2 highest metrics correlated to salary"
"very high correlation between age and years of experience which is expected as older employees tend to have more work experience"
"previous companies has low correlation with salary indicating that switching jobs frequently does not necessarily lead to higher pay"

# Salary vs Gender
sns.boxplot(data=df, x='gender', y='salary', ax=axes[0], palette='Set2')
axes[0].set_title('Salary Distribution by Gender')

# Salary vs Education Level
sns.boxplot(data=df, x='education_level', y='salary', ax=axes[1], palette='Set3', order=['High School', "Associate's", 'Bachelors', 'Masters', 'PhD'])
axes[1].set_title('Salary Distribution by Education Level')

# Salary vs Industry
sns.boxplot(data=df, x='industry', y='salary', ax=axes[2], palette='Pastel1')
axes[2].set_title('Salary Distribution by Industry')

plt.tight_layout()
plt.savefig('salary_distributions.png')
plt.close()

"clear upward trend in salary as PHD > Masters > Bachelors > Associate's > High School"
"median salary is kinda the same for both male and female"
