import numpy as np 
import pandas as pd
import matplotlib.pyplot as plt
import sklearn.linear_model as LR
data= pd.read_csv("linear_regression_dataset.csv")
n= data.shape[0]
p= data.shape[1]-1
x_raw=data.iloc[:,0:11]
y=data.iloc[:,-1]
ones= np.ones((x_raw.shape[0],1))
x=np.column_stack((ones,x_raw))
xtx=(x.T @ x)
LR_model= LR.LinearRegression(fit_intercept= False)
LR_model.fit(x,y)
residuals= (y - LR_model.predict(x))
H= x @ np.linalg.inv(xtx) @ x.T
leverage= np.diagonal(H)
mse = np.sum(residuals**2) / (n - (p + 1))
cooks_d = (residuals**2 / (mse * (p + 1))) * (leverage / (1 - leverage)**2)
fig, ax = plt.subplots(1, 2, figsize=(12, 6))
leverage_thresh = 2 * (p + 1) / n
ax[0].scatter(range(len(leverage)), leverage)
ax[0].axhline(y=leverage_thresh, color='r')
cooks_thresh = 4 / n
ax[1].scatter(range(n), cooks_d, color='orange')
ax[1].axhline(y=cooks_thresh, color='r')
plt.show()
"Leverage scores indicate the influence of each data point on the fitted values in linear regression."
"High leverage points can disproportionately affect the regression results."
"They are useful for identifying potential outliers or influential observations in the dataset."
"Cook's distance combines information about the residuals and leverage to assess the overall influence of each data point on the regression model."
"Points with high Cook's distance values are considered influential"