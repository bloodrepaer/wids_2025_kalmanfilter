import numpy as np 
import pandas as pd
import matplotlib.pyplot as plt
import sklearn.linear_model as LR
import scipy.stats as stats
data= pd.read_csv("linear_regression_dataset.csv")
x_raw=data.iloc[:,0:11]
y=data.iloc[:,-1]
ones= np.ones((x_raw.shape[0],1))
x=np.column_stack((ones,x_raw))
LR_model= LR.LinearRegression(fit_intercept= False)
LR_model.fit(x,y)

residuals= (y - LR_model.predict(x))
y_plot= LR_model.predict(x)
import numpy as np 
import pandas as pd
import matplotlib.pyplot as plt
import sklearn.linear_model as LR
data= pd.read_csv("linear_regression_dataset.csv")
x_raw=data.iloc[:,0:11]
y=data.iloc[:,-1]
ones= np.ones((x_raw.shape[0],1))
x=np.column_stack((ones,x_raw))
LR_model= LR.LinearRegression(fit_intercept= False)
LR_model.fit(x,y)
import numpy as np 
import pandas as pd
import matplotlib.pyplot as plt
import sklearn.linear_model as LR
data= pd.read_csv("linear_regression_dataset.csv")
x_raw=data.iloc[:,0:11]
y=data.iloc[:,-1]
ones= np.ones((x_raw.shape[0],1))
x=np.column_stack((ones,x_raw))
LR_model= LR.LinearRegression(fit_intercept= False)
LR_model.fit(x,y)

residuals= (y - LR_model.predict(x))
stats.probplot(residuals, dist="norm", plot=plt)
plt.show()

"the data is right skewed as we can see the points deviate from the straight line on the upper right end of the plot"