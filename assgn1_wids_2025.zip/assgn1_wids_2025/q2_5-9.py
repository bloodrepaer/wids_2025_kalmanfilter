import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
import statsmodels.api as sm
import matplotlib.pyplot as plt
import seaborn as sns
df = pd.read_csv('salary_dataset.csv')
df['education_level'] = df['education_level'].fillna(df['education_level'].mode()[0])
df['years_experience'] = df['years_experience'].fillna(df['years_experience'].median())
df['performance_score'] = df['performance_score'].fillna(df['performance_score'].median())
df['education_level_encoded'] = df['education_level'].map({'HighSchool':0, "Associate's":1, 'Bachelors':2, 'Masters':3, 'PhD':4})
df['remote_worker_encoded'] = df['remote_worker'].map({'No':0, 'Yes':1})
df = pd.get_dummies(df, columns=['gender', 'industry', 'city', 'job_title'], drop_first=True, dtype=int)
df.drop(columns=['education_level', 'remote_worker'], inplace=True)
df['salary_bins'] = pd.qcut(df['salary'], q=5, labels=False)
X = df.drop(columns=['salary', 'salary_bins'])
y = df['salary']
model = LinearRegression()
model.fit(X, y)
sm_model = sm.OLS(y, sm.add_constant(X)).fit()
print(sm_model.summary())


"""7) From the OLS regression results, the five most influential features affecting salary are:
1. Industry: Retail
   - Coefficient: -17,815
   - Impact: Negative (Strong)
   - Interpretation: Working in the Retail industry is associated with a salary approximately $17,800 lower than the baseline industry (Finance), holding all else constant. This is the largest non-geographic driver of salary difference.
   2. Job Role 11 (Senior/Specialized Role)
   - Coefficient: +11,989
   - Impact: Positive
    - Interpretation: Specific job titles carry significant weight. "JobRole_11" (likely a Director or Principal Engineer level role based on the data context) commands a premium of nearly $12,000 over the baseline job role.
3. Job Role 13
    - Coefficient: +11,255
    - Impact: Positive
    - Interpretation: Similar to Role 11, this specific position adds roughly $11,250 to the annual compensation, indicating it is a high-value position within the company hierarchy.  
4. Education Level
    - Coefficient: +8,373
    - Impact: Positive
    - Interpretation: For every step up in education degree (e.g., from Bachelor's to Master's, or Master's to PhD), salary increases by about **$8,370**. This is a powerful "ladder" effect; a PhD (Level 4) would earn \~$(8370 x 2) = $16,740 more than a Bachelor's (Level 2) holder.
5. Industry: Healthcare
    - Coefficient: -6,183
    - Impact: Negative
    - Interpretation: The Healthcare sector in this dataset pays approximately $6,200 less than the baseline Finance sector, though the gap is much smaller than the drop seen in Retail."""


#8
rmse=np.sqrt(np.mean((y - model.predict(X)) ** 2))
mae=np.mean(np.abs(y - model.predict(X)))
r2=model.score(X, y)

print(f"RMSE: {rmse}")
print(f"MAE: {mae}")
print(f"R-squared: {r2}")

residuals_train = sm_model.resid
fitted_train = sm_model.fittedvalues

# Plot 1: Residuals vs Fitted (Linearity & Homoscedasticity)
plt.figure(figsize=(14, 6))

plt.subplot(1, 2, 1)
sns.scatterplot(x=fitted_train, y=residuals_train, alpha=0.3)
plt.axhline(0, color='red', linestyle='--')
plt.xlabel('Fitted Values')
plt.ylabel('Residuals')
plt.title('Residuals vs Fitted Values')

# Plot 2: Actual vs Predicted (Linearity check)
plt.subplot(1, 2, 2)
sns.scatterplot(x=y, y=fitted_train, alpha=0.3)
plt.plot([y.min(), y.max()], [y.min(), y.max()], 'r--')
plt.xlabel('Actual Values')
plt.ylabel('Predicted Values')
plt.title('Actual vs Predicted Values')

plt.tight_layout()
plt.show()