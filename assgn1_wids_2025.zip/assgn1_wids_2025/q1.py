import numpy as np 
import pandas as pd
import matplotlib.pyplot as plt
import sklearn.linear_model as LR
data= pd.read_csv("linear_regression_dataset.csv")
x_raw=data.iloc[:,0:11]
y=data.iloc[:,-1]
ones= np.ones((x_raw.shape[0],1))
x=np.column_stack((ones,x_raw))
xtx=(x.T @ x)
xtx_i=np.linalg.inv(xtx)
xty= x.T @ y
beta= xtx_i @ xty
print(beta) 

LR_model= LR.LinearRegression(fit_intercept= False)
LR_model.fit(x,y)
print(LR_model.coef_) 





 