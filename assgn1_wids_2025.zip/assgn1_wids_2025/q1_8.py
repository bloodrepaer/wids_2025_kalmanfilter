import numpy as np 
import pandas as pd
import matplotlib.pyplot as plt
import sklearn.linear_model as LR
data= pd.read_csv("linear_regression_dataset.csv")
x_raw=data.iloc[:,0:11]
y=data.iloc[:,-1]
ones= np.ones((x_raw.shape[0],1))
x=np.column_stack((ones,x_raw))
LR_model= LR.LinearRegression(fit_intercept= False)
LR_model.fit(x,y)

residuals= (y - LR_model.predict(x))

y_plot= LR_model.predict(x)
plt.scatter(y_plot, y)
plt.show()

"the homoscedasticity assumption is satisfied if the residuals have constant variance across all levels of the predicted values."
"if the spread would be in a funnel shape (either increasing or decreasing), it would indicate heteroscedasticity, meaning the variance of the residuals changes with the level of the predicted values."
"but as we can clearly see the spread is fairly constant this helps us identify that the variance is same across all predicted values"